//
//  TabBarController.swift
//  SmART-FORM
//
//  Created by Siyang Zhang on 8/22/17.
//  Copyright © 2017 Siyang Zhang. All rights reserved.
//

import UIKit
import Foundation

class TabBarController: UITabBarController {
    
}
